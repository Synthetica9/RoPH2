from WSD2 import WSD
import random as ra
import Tracking
import importlib
def StrawberryCandy(User):
	u=User
	uHP=u+"HP"
	uMAX=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"restored",uMAX*0.07,"HP!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP))+round(uMAX*0.07),file=f))
	print(u,"restored",uENE*0.07,"ENE!")
	print("---------------")

def SoothingSalve(User):
	u=User
	print("---------------")
	print(u,"is cured of a negative Status Effect!")
	print("---------------")

def PearlOintment(User):
	Target=input("Who are we using this on?\n ")
	print("---------------")
	print(Target,"had their TGH and RES boosted by 15 for this Turn!")
	setattr(WSD[Target],str(WSD[Target].TGH),+15)
	setattr(WSD[Target],str(WSD[Target].RES),+15)
	print("---------------")

def Walnut(User):
	u=User
	uHP=u+"HP"
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"restored 30HP!")
	print("---------------")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP))+30,file=f))
def CandyCane(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"restored 30ENE!")
	print("---------------")
	
def HerbalBandage(User):
	u=User
	t=input("Target is: ")
	tHP=WSD[t].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"used the Herbal Bandage!",t,"is healed for",tHP*0.3)
	print("---------------")

def HotCocoa(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"drank the Hot Cocoa! They regain",uENE*0.25,"ENE and,",uHP*0.25+"HP!")
	print("---------------")
def TomatoJuice(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"drank the Tomato Juice! They regain",uENE*0.3,"ENE!")
	print("---------------")
def OrangeJuice(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"drank the Orange Juice! They regain",uENE*0.3,"ENE and,",uHP*0.3+"HP!")
	print("---------------")

def FreshOrange(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"ate the Fresh Orange! They feel refreshed.")
	print(u,"recovers ",uHP*0.15+"HP and",uENE*0.15+"ENE!")
	print("---------------")
def SweetOrange(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"ate the Sweet Orange! They feel nice.")
	print(u,"recovers ",uHP*0.3+"HP and",uENE*0.3+"ENE!")
	print("---------------")
def TheFreshestOrange(User):
	u=User
	uMAX=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"ate The Freshest Orange! They feel exceptionally refreshed!")
	print(u+"'s HP is now",uMAX,"and their ENE is",uENE,"!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+str(uMAX),file=f)
	print("---------------")
def TheSweetestOrange(User):
	u=User
	uMAX=WSD[u].HP
	uENE=WSD[u].ENE
	uHP=u+"HP"
	Heal=round(uMAX*0.6)
	print("---------------")
	print(u,"ate The Sweetest Orange! They feel exceptionally nice!")
	print(u,"recovers",Heal+"HP and",uENE*0.6+"ENE!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP)+round(Heal))),file=f)
	print("---------------")

def RedApple(User):
	u=User
	uMAX=WSD[u].HP
	Heal=round(uMAX*0.15)
	uHP=u+"HP"
	print("---------------")
	print(u,"ate the Red Apple! They regain",Heal+"HP!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP)+round(Heal))),file=f)
	print(u,"is cured of a negative Status Effect!")
	print("---------------")
def GreenApple(User):
	u=User
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"ate the Green Apple! They regain",uENE*0.15+"ENE!")
	print(u,"is cured of a negative Status Effect!")
	print("---------------")
def GoldenApple(User):
	u=User
	uMAX=WSD[u].HP
	uENE=WSD[u].ENE
	Heal=round(uMAX*0.33)
	uHP=u+"HP"
	print("---------------")
	print(u,"ate the Golden Apple! They regain",Heal+"HP and",uENE*0.33+"ENE!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP)+round(Heal))),file=f)
	print(u,"is also cured of all negative Statuses!")
	print("---------------")

def HealthPotion(User):
	u=User
	uHP=u+"HP"
	Heal=round(WSD[u].HP*0.3)
	print("---------------")
	print(u,"drank the Health Potion! They regain",Heal+"HP!")
	with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
		importlib.reload(Tracking)
		print(u+"HP="+min(str(WSD[u].HP),str(getattr(Tracking,uHP)+round(Heal))),file=f)
	print("---------------")
def EnergyPotion(User):
	u=User
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"drank the Energy Potion! They regain",uENE*0.3+"ENE!")
	print("---------------")
def SuperPotion(User):
	u=User
	uHP=WSD[u].HP
	uENE=WSD[u].ENE
	print("---------------")
	print(u,"drank the Super Potion! They regain",uHP*0.5+"HP and",uENE*0.5+"ENE!")
	print("---------------")

def ThrowingStar(User):
	u=User
	uSTR=WSD[u].STR
	e=input("Target is: ")
	uLCK=WSD[u].LCK
	uSKL=WSD[u].SKL
	eTGH=WSD[e].TGH
	ePAR=WSD[e].PAR
	eEVA=WSD[e].EVA
	eHP=e+"HP"
	damage=round(uSTR*1.15-eTGH-ePAR*1.15)
	if ra.randint(1,100) >= 10-uLCK-uSKL-uSTR*0.25+eEVA:
		print("---------------")
		print(u,"landed a Direct Hit!",e,"is hit for",damage,"damage!")
		with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
			importlib.reload(Tracking)
			print(e+"HP="+str(getattr(Tracking,eHP)-round(damage)),file=f)
		print("---------------")
	else:
		print("---------------")
		print(u,"missed",e+"!")
		print("---------------")
def HandGrenade(User):
	u=User
	uSKL=WSD[u].SKL
	e=input("Target is: ")
	uLCK=WSD[u].LCK
	eTGH=WSD[e].TGH
	ePAR=WSD[e].PAR
	eEVA=WSD[e].EVA
	uABL=WSD[u].ABL
	eHP=e+"HP"
	damage=round(uABL*1.25-eTGH*0.75-ePAR)
	if ra.randint(1,100) >= 50-uLCK-uSKL-uABL*0.25+eEVA:
		print("---------------")
		print(u,"landed a Direct Hit!",e,"is hit for",round(damage),"damage!")
		with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
			importlib.reload(Tracking)
			print(e+"HP="+str(getattr(Tracking,eHP)-round(damage)),file=f)
		print("---------------")
	elif ra.randint(1,100) >= 25-uLCK-uSKL-uABL*0.25+eEVA*0.5:
		print("---------------")
		print(u,"landed a Glancing Hit!",e,"is hit for",round((damage)*0.5),"damage!")
		with open('C:\\Users\\seven\\OneDrive\\Desktop\\RoPH OOP Update\\For Testing Ideas\\Tracking.py','a+') as f:
			importlib.reload(Tracking)
			print(e+"HP="+str(getattr(Tracking,eHP)-round(damage)),file=f)
		print("---------------")
	else:
		print("---------------")
		print(u,"missed",e+"!")
		print("---------------")