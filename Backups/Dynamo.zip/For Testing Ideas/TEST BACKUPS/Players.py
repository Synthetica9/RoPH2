from WSD2 import WSD
from WeaponsOO import OmniWeaponData
from ArmorsOO import OmniArmorData
import AttacksOO
import Skills
import Items
import random as ra
import Skillcheck as Check
import Tracking
import importlib

class Element():
	def __init__(self,Type="None",Advantage="Nada",Disadvantage="Nope",Status="Nothing",Proc=0):
		self.Type=Type
		self.Advantage=Advantage
		self.Disadvantage=Disadvantage
		self.Same=Type
		self.Status=Status
		self.Proc=Proc
	@property
	def StatusProc(self):
		if ra.randint(1,100) >= 100-self.Proc:
			return("and you inflict the status",self.Status)
			print(" ")
		else:
			return("and you inflict no status at all.")
			print(" ")

Flame=Element("Flame","Earth","Water","Burning",25)
Earth=Element("Earth","Wind","Flame","Silence",25)
Wind=Element("Wind","Lightning","Earth","Clouded",25)
Lightning=Element("Lightning","Water","Wind","Shocked",25)
Water=Element("Water","Flame","Lightning","Waterlog",25)

Null=Element("None","Nada","Nope","Nothing",0)

Solar=Element("Solar","Lunar","Time","Flare",33)
Lunar=Element("Lunar","Storm","Solar","Calm",50)
Storm=Element("Storm","Void","Lunar","Stormscare",30)
Void=Element("Void","Time","Storm","Voidcall",30)
Time=Element("Time","Solar","Void","Timelock",20)

def Dummy(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")

def Jango(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [W]eapons!\n [I]nventory!\n [P]ickpocket!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Reinforced Bone Knife!\n [2] Reinforced Bone Knife!\n ")
		if choice == "1":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Tr]iple Combo!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Knife(WSD["Jango"].Weapon1,"Jango",Solar,1.4,0,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Knife(WSD["Jango"].Weapon1,"Jango",Solar,1.4,0,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Knife(WSD["Jango"].Weapon1,"Jango",Solar,1.4,0,0).HATK
			elif choice == "TR" or choice == "Tr" or choice == "tr":
				AttacksOO.Knife(WSD["Jango"].Weapon1,"Jango",Solar,1.4,0,0).TripleCombo
			elif choice == "SU" or choice == "Su" or choice == "su":
				Skills.Surprise("Jango","ReinforcedBoneKnife0","ReinforcedBoneKnife0","Solar","Solar")
		elif choice == "2":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Tr]iple Combo!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Knife(WSD["Jango"].Weapon2,"Jango",Solar,1.4,0,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Knife(WSD["Jango"].Weapon2,"Jango",Solar,1.4,0,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Knife(WSD["Jango"].Weapon2,"Jango",Solar,1.4,0,0).HATK
			elif choice == "TR" or choice == "Tr" or choice == "tr":
				AttacksOO.Knife(WSD["Jango"].Weapon2,"Jango",Solar,1.4,0,0).TripleCombo
			elif choice == "SU" or choice == "Su" or choice == "su":
				Skills.Surprise("Jango","ReinforcedBoneKnife0","ReinforcedBoneKnife0","Solar","Solar")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n [Sh]uriken!\n [Or]ange Juice!\n ")
		if choice == "SH" or choice == "Sh" or choice == "sh":
			Items.Shuriken("Jango")
		elif choice == "OR" or choice == "Or" or choice == "or":
			Items.OrangeJuice("Jango")
	elif choice == "P" or choice == "p":
		AttacksOO.Pickpocket("Jango")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Jango",1).Choice

def Helm(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Copper Saber!\n [2] Ivory Handbow!\n ")
		if choice == "1":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Tr]iple Combo!\n [Be]ginner's Parry!\n [Bl]azing Cutlass!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Storm,1.25,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Storm,1.25,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Storm,1.25,0).HATK
			elif choice == "TR" or choice == "Tr" or choice == "tr":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Storm,1.25,0).TripleCombo
			elif choice == "BE" or choice == "Be" or choice == "be":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Storm,1.25,0).BeginnersParry
			elif choice == "BL" or choice == "Bl" or choice == "bl":
				AttacksOO.Saber("NormalCopperSaber0","Helm",Flame,1.25,0).BlazingCutlass
		elif choice == "2":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Tr]iple Play!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Handbow("NormalIvoryHandbow0","Helm",Storm,1,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Handbow("NormalIvoryHandbow0","Helm",Storm,1,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Handbow("NormalIvoryHandbow0","Helm",Storm,1,0).HATK
			elif choice == "TR" or choice == "Tr" or choice == "tr":
				AttacksOO.Handbow("NormalIvoryHandbow0","Helm",Storm,1,0).TriplePlay
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n [HB] Herbal Bandage!\n [TJ] Tomato Juice!\n")
		if choice == "HB" or choice == "Hb" or choice == "hb":
			Items.HerbalBandage("Helm")
		elif choice == "TJ" or choice == "Tj" or choice == "tj":
			Items.TomatoJuice("Helm")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Helm",1).Choice

def Roselyn(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Su]pport Magic!\n [H]ealing Field!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Ivory Wand!\n [2] Cobalt Battlecannon!\n ")
		if choice == "1":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Fi]reball!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Wand("NormalIvoryWand0","Roselyn",Flame,1,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Wand("NormalIvoryWand0","Roselyn",Flame,1,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Wand("NormalIvoryWand0","Roselyn",Flame,1,0).HATK
			elif choice == "FI" or choice == "Fi" or choice == "fi":
				AttacksOO.OffenseSpell("NormalIvoryWand0","Roselyn",Flame,1.15,0,0).Fireball
		elif choice == "2":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Battlecannon("NormalCobaltBattlecannon0","Roselyn",Flame,0.5,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Battlecannon("NormalCobaltBattlecannon0","Roselyn",Flame,0.5,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Battlecannon("NormalCobaltBattlecannon0","Roselyn",Flame,0.5,0).HATK
	elif choice == "SU" or choice == "Su" or choice == "su":
		choice=input("Select a Spell!\n [HR] Healthy Ray!\n [HG] Healthy Glow!\n [EG] Energetic Glow!\n [ER] Energetic Ray!\n ")
		if choice == "HR" or choice == "Hr" or choice == "hr":
			AttacksOO.SupportSpell("NormalIvoryWand0","Roselyn").HealthyRay
		elif choice == "HG" or choice == "Hg" or choice == "hg":
			Skills.HealthyGlow("Roselyn","NormalIvoryWand0")
		elif choice == "ER" or choice == "Er" or choice == "er":
			Skills.EnergeticRay("Roselyn","NormalIvoryWand0")
		elif choice == "EG" or choice == "Eg" or choice == "eg":
			Skills.EnergeticGlow("Roselyn","NormalIvoryWand0")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n [SC] Strawberry Candy!\n [PO] Pearl Ointment!\n [SS] Soothing Salve!\n ")
		if choice == "SC" or choice == "Sc" or choice == "sc":
			Items.StrawberryCandy("Roselyn")
		elif choice == "PO" or choice == "Po" or choice == "po":
			Items.PearlOintment("Roselyn")
		elif choice == "SS" or choice == "Ss" or choice == "ss":
			Items.SoothingSalve("Roselyn")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Roselyn",1).Choice
		
def Brad(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n ")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n ")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Brad",1).Choice
		
def Gilligan(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Wood Claw!\n [2] Bone Knuckle!\n ")
		if choice == "1":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Bl]oody Slashes!\n [Fu]ry Thrust!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Claw("NormalWoodClaw0","Gilligan",Wind,1,0,20).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Claw("NormalWoodClaw0","Gilligan",Wind,1,0,20).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Claw("NormalWoodClaw0","Gilligan",Wind,1,0,20).HATK
			elif choice == "BL" or choice == "Bl" or choice == "bl":
				AttacksOO.Claw("NormalWoodClaw0","Gilligan",Wind,1,0,20).BloodySlashes
			elif choice == "FU" or choice == "Fu" or choice == "fu":
				AttacksOO.Claw("NormalWoodClaw0","Gilligan",Wind,1,0,20).FuryThrust
		elif choice == "2":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Fl]icker Jab!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Knuckles("NormalBoneKnuckles0","Gilligan",Wind,1,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Knuckles("NormalBoneKnuckles0","Gilligan",Wind,1,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Knuckles("NormalBoneKnuckles0","Gilligan",Wind,1,0).HATK
			elif choice == "FL" or choice == "Fl" or choice == "fl":
				AttacksOO.Knuckles("NormalBoneKnuckles0","Gilligan",Wind,1,0).FlickerJab
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n ")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Gilligan",2).Choice

def Yule(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n ")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n ")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Yule",2).Choice

def StClips(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Festive Firwood Mechgun+2!\n ")
		if choice == "1":
			choice=input("[Q]uick!\n [N]ormal!\n [H]ard!\n [Dr]izzle!\n [Bl]itz!\n ")
			if choice == "AT" or choice == "At" or choice == "at":
				Attacks.MechgunManiac("StClips","FestiveWoodMechgun2","Earth")
			elif choice == "DR" or choice == "Dr" or choice == "dr":
				Skills.DrizzleManiac("StClips","FestiveWoodMechgun2","Earth")
			elif choice == "BL" or choice == "Bl" or choice == "bl":
				Skills.BlitzManiac("StClips","FestiveWoodMechgun2","Earth")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n ")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("StClips",2).Choice

def Reyn(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Stony Tungsten Greatsword!\n [2] Tungsten Spear!\n [3] Eye Laser!\n ")
		if choice == "1":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [He]avy Stab!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.GreatswordGrinder("StonyTungstenGreatsword0","Reyn",Earth,1.5,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.GreatswordGrinder("StonyTungstenGreatsword0","Reyn",Earth,1.5,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.GreatswordGrinder("StonyTungstenGreatsword0","Reyn",Earth,1.5,0).HATK
			elif choice == "HE" or choice == "He" or choice == "he":
				AttacksOO.GreatswordGrinder("StonyTungstenGreatsword0","Reyn",Earth,1.5,0).HeavyStab
		elif choice == "2":
			choice=input("Select an action!\n [Q]uick!\n [N]ormal!\n [H]ard!\n [Tr]ipoint Buster!\n [Cu]two!\n ")
			if choice == "Q" or choice == "q":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).QATK
			elif choice == "N" or choice == "n":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).NATK
			elif choice == "H" or choice == "h":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).HATK
			elif choice == "TR" or choice == "Tr" or choice == "tr":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).TripointBuster
			elif choice == "CU" or choice == "Cu" or choice == "cu":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).Cutwo
			elif choice == "PP" or choice == "Pp" or choice == "pp":
				AttacksOO.Polearm("NormalTungstenPolearm0","Reyn",Lightning,1.35,0).PiercingPounce
		elif choice == "3":
			AttacksOO.Weaponless("Reyn",Lightning,1,0,2).EyeLaser
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n [Ha]nd Grenade!\n ")
		if choice == "HA" or choice == "Ha" or choice == "ha":
			Items.HandGrenade("Reyn")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Reyn",2).Choice
#Separator Line
def Lirru(Unit):
	u=Unit
	uHP=WSD[Unit].HP
	uENE=WSD[Unit].ENE
	uSTR=WSD[Unit].STR
	uSPR=WSD[Unit].SPR
	uSKL=WSD[Unit].SKL
	uABL=WSD[Unit].ABL
	uAGI=WSD[Unit].AGI
	uEVA=WSD[Unit].EVA
	uTGH=WSD[Unit].TGH
	uRES=WSD[Unit].RES
	uLCK=WSD[Unit].LCK
	uPAR=WSD[Unit].PAR
	uMAR=WSD[Unit].MAR
	uWT=WSD[Unit].ArmorWT
	choice=input("Select something!\n [St]atcheck!\n [At]tack!\n [I]nventory!\n [Sk]illcheck!\n ")
	if choice=="ST" or choice == "St" or choice == "st":
		print("-----------------")
		print("HP:",uHP)
		print("ENE:",uENE)
		print("STR:",uSTR)
		print("SPR:",uSPR)
		print("SKL:",uSKL)
		print("ABL:",uABL)
		print("AGI:",uAGI)
		print("EVA:",uEVA)
		print("TGH:",uTGH)
		print("RES:",uRES)
		print("LCK:",uLCK)
		print("PAR:",uPAR)
		print("MAR:",uMAR)
		print("WT:",uWT)
		print("-----------------")
	elif choice=="AT" or choice=="At" or choice == "at":
		choice=input("Which weapon?\n [1] Tungsten Saber!\n [2] Silk Glove!\n ")
	elif choice == "I" or choice == "i":
		choice=input("Select an item!\n ")
	elif choice == "SK" or choice == "Sk" or choice == "sk":
		Check.Skillcheck("Lirru",2).Choice