from DressingRoomOO import OmniUnitData
from MonsterFactoryOO import OmniMonsterData
#The commented-out values are the base values. Reset to them when a Wave ends.
#ReynHP=int(OmniUnitData["WilderKnightWI2"][0])
#RoselynHP=int(OmniUnitData["WilderMedicWI1"][0])
#HelmHP=int(OmniUnitData["OriginVagabondOR1"][0])
#JangoHP=int(OmniUnitData["SoulbladeThiefSB1"][0])
#JosephineHP=int(OmniUnitData["OriginThiefOR1"][0])
#WanderHP=int(OmniUnitData["OriginMedicOR2"][0])
#JanetHP=int(OmniUnitData["OriginArcherOR2"][0])
#OneHP=int(OmniUnitData["SoulbladeMonkSB4"][0])
ReynHP=int(OmniUnitData["WilderKnightWI2"][0])
RoselynHP=int(OmniUnitData["WilderMedicWI1"][0])
HelmHP=int(OmniUnitData["OriginVagabondOR1"][0])
JangoHP=int(OmniUnitData["SoulbladeThiefSB1"][0])
JosephineHP=int(OmniUnitData["OriginThiefOR1"][0])
WanderHP=int(OmniUnitData["OriginMedicOR2"][0])
JanetHP=int(OmniUnitData["OriginArcherOR2"][0])
#Separator Line
JangoHP=66
GachumHP=24
OgreHP=63
DummyHP=9999
