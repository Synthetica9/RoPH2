from DressingRoomOO import OmniUnitData
from MonsterFactoryOO import OmniMonsterData
#The commented-out values are the base values. Reset to them when a Wave ends.
#ReynENE=int(OmniUnitData["WilderKnightWI2"][1])
#GilliganENE=int(OmniUnitData["SoulbladeMonkSB2"][1])
#RoselynENE=int(OmniUnitData["WilderMedicWI1"][1])
#HelmENE=int(OmniUnitData["OriginVagabondOR1"][1])
#JangoENE=int(OmniUnitData["SoulbladeThiefSB1"][1])
#JosephineENE=int(OmniUnitData["OriginThiefOR1"][1])
#WanderENE=int(OmniUnitData["OriginMedicOR2"][1])
#JanetENE=int(OmniUnitData["OriginArcherOR2"][1])
#OneENE=int(OmniUnitData["SoulbladeMonkSB4"][1])

ReynENE=int(OmniUnitData["WilderKnightWI2"][1])
RoselynENE=int(OmniUnitData["WilderMedicWI1"][1])
HelmENE=int(OmniUnitData["OriginVagabondOR1"][1])
JangoENE=int(OmniUnitData["SoulbladeThiefSB1"][1])
JosephineENE=int(OmniUnitData["OriginThiefOR1"][1])
WanderENE=int(OmniUnitData["OriginMedicOR2"][1])
JanetENE=int(OmniUnitData["OriginArcherOR2"][1])
OneENE=int(OmniUnitData["SoulbladeMonkSB4"][1])
GilliganENE=int(OmniUnitData["SoulbladeMonkSB2"][1])
